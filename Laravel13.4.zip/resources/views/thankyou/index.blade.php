@extends('layouts.master')

@section('extra-meta')
<meta name="csrf-token" content="{{ csrf_token() }}">
@endsection


@section('titleSite')
    <title>{{ \App\Agence::first()->nom_agence}} - Checkout</title>
@endsection



@section('bannerArea')
<!-- start banner Area -->
<section class="about-banner relative">
    <div class="overlay overlay-bg"></div>
    <div class="container">
        <div class="row d-flex align-items-center justify-content-center">
            <div class="about-content col-lg-12">
                <h1 class="text-white">
                    Panier
                </h1>
                <p class="text-white link-nav"><a href="{{ route('/') }}" class="mr-3">accueil </a> <span class="fa fa-angle-right"></span> <a href="{{ route('checkout.index') }}" class="ml-3"> Checkout</a></p>
            </div>
        </div>
    </div>
</section>
<!-- End banner Area -->

@endsection

@section('content-noSidebar')

	<h1> Merci </h1>




@endsection

