@extends('layouts.master')

@section('titleSite')
    <title>{{ \App\Agence::first()->nom_agence}} - Commandes</title>
@endsection


@section('bannerArea')
<!-- start banner Area -->
<section class="about-banner relative">
    <div class="overlay overlay-bg"></div>
    <div class="container">
        <div class="row d-flex align-items-center justify-content-center">
            <div class="about-content col-lg-12">
                <h1 class="text-white">
                    Panier
                </h1>
                <p class="text-white link-nav"><a href="{{ route('/') }}" class="mr-3">accueil </a> <span class="fa fa-angle-right"></span> <a href="{{ route('cart.index') }}" class="ml-3"> Panier</a></p>
            </div>
        </div>
    </div>
</section>
<!-- End banner Area -->

@endsection

@section('content-noSidebar')

@if (App\Panier::where('user_id', Auth()->user()->id)->count())

<div class="px-4 px-lg-0">
    <div class="pb-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 p-5 bg-white rounded shadow-sm mb-5">
                    <!-- Shopping cart table -->
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col" class="border-0 bg-light">
                                        <div class="p-2 px-3 text-uppercase">Produit</div>
                                    </th>
                                    <th scope="col" class="border-0 bg-light">
                                        <div class="py-2 text-uppercase">Prix</div>
                                    </th>
                                    <th scope="col" class="border-0 bg-light">
                                        <div class="py-2 text-uppercase">Quantité</div>
                                    </th>
                                    <th scope="col" class="border-0 bg-light">
                                        <div class="py-2 text-uppercase">Supprimer</div>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($products as $product)
                                @if($product->service_type === 'voitures')
                                <tr>

                                    <th scope="row" class="border-0">
                                        <div class="p-2">
                                            <img src="{{ $product->image }}" alt="" width="70" class="img-fluid rounded shadow-sm">
                                            <div class="ml-3 d-inline-block align-middle">
                                                <h5 class="mb-0"> <a href="{{ route('voitures.show', ['slug' => $product->slug]) }}" class="text-dark d-inline-block align-middle">{{ $product->titre }}</a></h5><span class="text-muted font-weight-normal font-italic d-block">Category: Voiture</span>
                                            </div>
                                        </div>
                                    </th>
                                    <td class="border-0 align-middle">
                                        <strong>{{ getPrice2($product->prix) }}</strong>
                                    </td>
                                    <td class="border-0 align-middle"><strong>1</strong></td>
                                    <td class="border-0 align-middle">
                                        <form action="{{ route('panier.supprimerService', $product->slug) }}" method="POST">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-danger"><i class="fa fa-trash"></i></a>
                                        </form>
                                    </td>
                                </tr>
                                @endif
                                @if($product->service_type === 'vols')
                                <tr>

                                    <th scope="row" class="border-0">
                                        <div class="p-2">
                                            <img src="{{ $product->image }}" alt="" width="70" class="img-fluid rounded shadow-sm">
                                            <div class="ml-3 d-inline-block align-middle">
                                                <h5 class="mb-0"> <a href="{{ route('voitures.show', ['slug' => $product->slug]) }}" class="text-dark d-inline-block align-middle">{{ $product->titre }}</a></h5><span class="text-muted font-weight-normal font-italic d-block">Category: vols</span>
                                            </div>
                                        </div>
                                    </th>
                                    <td class="border-0 align-middle">
                                        <strong>{{ getPrice2($product->prix) }}</strong>
                                    </td>
                                    <td class="border-0 align-middle"><strong>1</strong></td>
                                    <td class="border-0 align-middle">
                                        <form action="{{ route('panier.supprimerService', $product->slug) }}" method="POST">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-danger"><i class="fa fa-trash"></i></a>
                                        </form>
                                    </td>
                                </tr>
                                @endif

                                @if($product->service_type === 'hotels')
                                <tr>

                                    <th scope="row" class="border-0">
                                        <div class="p-2">
                                            <img src="{{ $product->image }}" alt="" width="70" class="img-fluid rounded shadow-sm">
                                            <div class="ml-3 d-inline-block align-middle">
                                                <h5 class="mb-0"> <a href="{{ route('voitures.show', ['slug' => $product->slug]) }}" class="text-dark d-inline-block align-middle">{{ $product->titre }}</a></h5><span class="text-muted font-weight-normal font-italic d-block">Category: hotels</span>
                                            </div>
                                        </div>
                                    </th>
                                    <td class="border-0 align-middle">
                                        <strong>{{ getPrice2($product->prix) }}</strong>
                                    </td>
                                    <td class="border-0 align-middle"><strong>1</strong></td>
                                    <td class="border-0 align-middle">
                                        <form action="{{ route('panier.supprimerService', $product->slug) }}" method="POST">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-danger"><i class="fa fa-trash"></i></a>
                                        </form>
                                    </td>
                                </tr>
                                @endif
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    <!-- End -->
                </div>
            </div>
            <div class="row py-5 p-4 bg-white rounded shadow-sm">
                <div class="col-lg-6">
                    <div class="bg-light rounded-pill px-4 py-3 text-uppercase font-weight-bold">Coupon code</div>
                    <div class="p-4">
                        <p class="font-italic mb-4">If you have a coupon code, please enter it in the box below</p>
                        <div class="input-group mb-4 border rounded-pill p-2">
                            <input type="text" placeholder="Apply coupon" aria-describedby="button-addon3" class="form-control border-0">
                            <div class="input-group-append border-0">
                                <button id="button-addon3" type="button" class="btn btn-dark px-4 rounded-pill"><i class="fa fa-gift mr-2"></i>Apply coupon</button>
                            </div>
                        </div>
                    </div>
                    <div class="bg-light rounded-pill px-4 py-3 text-uppercase font-weight-bold">Instructions for seller</div>
                    <div class="p-4">
                        <p class="font-italic mb-4">If you have some information for the seller you can leave them in the box below</p>
                        <textarea name="" cols="30" rows="2" class="form-control"></textarea>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="bg-light rounded-pill px-4 py-3 text-uppercase font-weight-bold">Détails de la commande </div>
                    <div class="p-4">
                        <p class="font-italic mb-4">Shipping and additional costs are calculated based on values you have entered.</p>
                        <ul class="list-unstyled mb-4">
                            <li class="d-flex justify-content-between py-3 border-bottom"><strong class="text-muted">Sous-total </strong><strong>{{ getPrice2(Cart::subtotal()) }}</strong></li>
                            {{-- <li class="d-flex justify-content-between py-3 border-bottom"><strong class="text-muted">Shipping and handling</strong><strong>$10.00</strong></li> --}}
                            <li class="d-flex justify-content-between py-3 border-bottom"><strong class="text-muted">Taxe</strong><strong>{{ getPrice2(Cart::tax()) }}</strong></li>
                            <li class="d-flex justify-content-between py-3 border-bottom"><strong class="text-muted">Total</strong>
                                <h5 class="font-weight-bold">{{ getPrice2(Cart::total()) }}</h5>
                            </li>
                        </ul><a href="{{ route('checkout.index')}}" class="btn btn-dark rounded-pill py-2 btn-block">Passer à la caisse</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@else
    <div class="col-md-12">
        <p>Votre panier est vide.</p>
    </div>
@endif

@endsection