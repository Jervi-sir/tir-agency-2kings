@component('mail::message')

# Demande d'assistance personnalisée


{{ request('message') }}


@endcomponent